<?php
	define('DB_HOSTNAME', 'hpcsphere.com');

	define('DB_USERNAME', 'hpcspher');

	define('DB_PASSWORD', '0x000FF1CE');

	define('DB_DATABASE', 'hpcspher_products');	

?>